#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "memory.h"


// MEMORY ARRAYS
// Each processor has independent instruction and data memory.

unsigned char Instruction[NP][INSTRUCTION_MEM_SIZE];      // Instruction[processor][address]
unsigned char Data[NP][DATA_MEM_SIZE];                    // Data[processor][address]


void clear_memory(int processor_id){
    if (processor_id < 0 || processor_id >= NP){
        printf("Invalid processor ID: %d\n", processor_id);

        return;
    }

    memset(Instruction[processor_id], 0, INSTRUCTION_MEM_SIZE);
    memset(Data[processor_id], 0, DATA_MEM_SIZE);
}

// INITIALIZE MEMORY
int initialize_memory(int processor_id, const char *program_file, const char *data_file){
    FILE *fp;

    int value;
    int index;

    // CHECK PROCESSOR ID
    if (processor_id < 0 || processor_id >= NP){
        printf("Invalid processor ID: %d\n", processor_id);

        return 0;
    }

    // CHECK FILE NAMES
    if (program_file == NULL || data_file == NULL){
        printf("Invalid program or data file.\n");

        return 0;
    }
    
    // CLEAR MEMORY FIRST
    clear_memory(processor_id);

    fp = fopen(program_file, "r");
    if (fp == NULL){
        printf("Cannot open program file: %s\n", program_file);

        return 0;
    }

    index = 0;

    while (fscanf(fp, "%x", &value) == 1){
        // One instruction byte = one memory location.

        if (index >= INSTRUCTION_MEM_SIZE){
            printf("Instruction memory overflow " "for processor %d.\n", processor_id);

            fclose(fp);
            return 0;
        }

        //Each byte must be 0x00 - 0xFF.
        if (value < 0 || value > 255){
            printf("Invalid instruction byte: %X\n", value);

            fclose(fp);
            return 0;
        }


        Instruction[processor_id][index] = (unsigned char)value;
        index++;
    }

    fclose(fp);
    
    // LOAD DATA.BYTE
    fp = fopen(data_file, "r");

    if (fp == NULL){
        printf("Cannot open data file: %s\n", data_file);

        return 0;
    }

    index = 0;
    while (fscanf(fp, "%x", &value) == 1){
        // Data memory contains individual bytes.

        if (index >= DATA_MEM_SIZE){
            printf("Data memory overflow " "for processor %d.\n", processor_id);

            fclose(fp);
            return 0;
        }

        // Validate byte
        if (value < 0 || value > 255){
            printf("Invalid data byte: %X\n",value);

            fclose(fp);
            return 0;
        }


        Data[processor_id][index] = (unsigned char)value;
        index++;
    }

    fclose(fp);

    // SUCCESS
    printf("\nMEMORY INITIALIZED\n");

    printf("\nProcessor : %d\n", processor_id);
    printf("\nProgram : %s\n",program_file);
    printf("\nData : %s\n",data_file);

    return 1;
}

// READ 32-BIT VALUE 
// Data is stored in little-endian format:

// address + 0 -> least significant byte
// address + 1
// address + 2
// address + 3 -> most significant byte

int32_t read32(int processor_id, int address){
    uint32_t value;

    // VALIDATE PROCESSOR
    if (processor_id < 0 || processor_id >= NP){
        printf("Invalid processor ID: %d\n", processor_id);

        return 0;
    }

    // VALIDATE ADDRESS
    // Four bytes are required. Therefore the last valid starting address is: DATA_MEM_SIZE - 4
    if (address < 0 || address + 3 >= DATA_MEM_SIZE){
        printf("Invalid memory address: %d\n", address);

        return 0;
    }
    
    // BUILD 32-BIT VALUE
    value =((uint32_t)Data[processor_id][address]) | 
    ((uint32_t)Data[processor_id][address + 1] << 8) | 
    ((uint32_t)Data[processor_id][address + 2] << 16) | 
    ((uint32_t)Data[processor_id][address + 3] << 24);

    return (int32_t)value;
}

// WRITE 32-BIT VALUE
void write32( int processor_id, int address, int32_t value){
    uint32_t v;

    // VALIDATE PROCESSOR
    if (processor_id < 0 || processor_id >= NP){
        printf("Invalid processor ID: %d\n", processor_id);

        return;
    }

    // VALIDATE ADDRESS
    if (address < 0 || address + 3 >= DATA_MEM_SIZE){
        printf("Invalid memory address: %d\n", address);

        return;
    }

    // CONVERT TO UNSIGNED REPRESENTATION
    v = (uint32_t)value;
    
    // STORE LITTLE-ENDIAN
    
    Data[processor_id][address] = (unsigned char)(v & 0xFF);
    Data[processor_id][address + 1] = (unsigned char)((v >> 8) & 0xFF);
    Data[processor_id][address + 2] = (unsigned char)((v >> 16) & 0xFF);
    Data[processor_id][address + 3] = (unsigned char)((v >> 24) & 0xFF);
}

// FINALIZE MEMORY
int finalize_memory(int processor_id, const char *data_file){
    FILE *fp;
    int i;

    // VALIDATE PROCESSOR
    if (processor_id < 0 || processor_id >= NP){
        printf("Invalid processor ID: %d\n", processor_id);

        return 0;
    }

    // VALIDATE FILE
    if (data_file == NULL){
        printf("Invalid data file.\n");

        return 0;
    }

    // OPEN DATA FILE
    fp = fopen(data_file, "w");

    if (fp == NULL){
        printf("Cannot write data file: %s\n", data_file);

        return 0;
    }

    // WRITE MEMORY

    // Four bytes are printed on every line.
    // Example: 08 00 00 00 represents integer 8.
    for (i = 0; i < DATA_MEM_SIZE; i += 4){
        fprintf(fp, "%02X %02X %02X %02X\n", Data[processor_id][i], 
            Data[processor_id][i + 1], Data[processor_id][i + 2], Data[processor_id][i + 3]);
    }

    fclose(fp);

    printf("\nMEMORY FINALIZED\n");

    printf("Processor : %d\n", processor_id);
    printf("Data      : %s\n", data_file);


    return 1;
}