#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>

#define NP 4    //Number of processors
#define INSTRUCTION_MEM_SIZE 256
#define DATA_MEM_SIZE 4096

extern unsigned char Instruction[NP][INSTRUCTION_MEM_SIZE];
extern unsigned char Data[NP][DATA_MEM_SIZE];

int initialize_memory(int processor_id, const char *program_file, const char *data_file);
int32_t read32(int processor_id, int address);
void write32(int processor_id, int address, int32_t value);
int finalize_memory(int processor_id, const char *data_file);

#endif